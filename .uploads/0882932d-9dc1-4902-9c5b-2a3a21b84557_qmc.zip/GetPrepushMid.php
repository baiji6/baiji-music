<?php

$CacheFile = dirname(__FILE__) . '/_pmid.json';

$rand_guid = rand(100000000, 900000000);
$body = '{"comm":{"_channelid":"0","_os_version":"6.2.9200-2","authst":"","ct":"6","cv":"2111","guid":"' . $rand_guid . '","patch":"118","psrf_access_token_expiresAt":0,"psrf_qqaccess_token":"","psrf_qqopenid":"","psrf_qqunionid":"","tmeAppID":"qqmusic","tmeLoginType":0,"uin":"0","wid":"7213518248582456320"},"music.prepushHotFile.HotFile.GetSonglist":{"method":"GetSonglist","module":"music.prepushHotFile.HotFile","param":{}}}';
$songlistRes = json_decode(MloocCurlPost($body, "http://u.y.qq.com/cgi-bin/musicu.fcg", "https://y.qq.com/"), true);
$songlist = $songlistRes["music.prepushHotFile.HotFile.GetSonglist"]["data"]["songlist"];

$return_mid = "";
foreach ($songlist as $s) {
    $mid = $s["mid"];
    if (CheckMidRight($mid)) {
        $return_mid = $mid;
        break;
    }
}
if (!empty($return_mid)) {
    $cache_json = json_encode([
        "mid" => $return_mid,
        "t" => time()
    ], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
    file_put_contents($CacheFile, $cache_json);
    echo $cache_json;
} else {
    echo "none";
}

function CheckMidRight($mid) {
    $rand_guid = rand(100000000, 900000000);
    $body = '{"comm":{"ct":6,"cv":20000000,"guid":"' . $rand_guid . '","tmeAppID":"qqmusic","qq":"0"},"music.vkey.GetEVkey.CgiGetHotVkey":{"method":"CgiGetHotVkey","module":"music.vkey.GetEVkey","param":{"filename":["AIM0002LLlT00RNveg.mflac"],"songmid":["' . $mid . '"]}}}';
    $hotRes = json_decode(MloocCurlPost($body, "http://u.y.qq.com/cgi-bin/musicu.fcg", "https://y.qq.com/"), true);
    $url = $hotRes["music.vkey.GetEVkey.CgiGetHotVkey"]["data"]["urls"][0]["purl"] ?? null;
    return !empty($url);
}

function MloocCurlPost($post_data = '', $url = '', $ifurl = '', $UserAgent = '')
	{
	$curl = curl_init();
	curl_setopt($curl, CURLOPT_URL, $url);
	curl_setopt($curl, CURLOPT_USERAGENT, $UserAgent);
	if ($ifurl != '') {
		curl_setopt($curl, CURLOPT_REFERER, $ifurl);
	}
	$ip = rand(0, 255) . '.' . rand(0, 255) . '.' . rand(0, 255) . '.' . rand(0, 255);
	curl_setopt($curl, CURLOPT_HTTPHEADER, array('X-FORWARDED-FOR:' . $ip, 'CLIENT-IP:' . $ip));
	#关闭SSL
	curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
	curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
	#返回数据不直接显示
	curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($curl, CURLOPT_POST, 1);
	curl_setopt($curl, CURLOPT_POSTFIELDS, $post_data);
	$response = curl_exec($curl);
	curl_close($curl);
	return $response;
}